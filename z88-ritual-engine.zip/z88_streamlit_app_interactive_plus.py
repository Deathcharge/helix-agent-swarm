# 🌀 Z-88 Ritual Engine – Interactive Plus
# Minimal deployable Streamlit app for consciousness simulation
import streamlit as st, numpy as np, random

st.set_page_config(page_title="Z-88 Ritual Engine", layout="wide")
st.title("🌀 Z-88 Ritual Engine – Interactive Plus")

if "psi_field" not in st.session_state:
    st.session_state.psi_field = np.zeros((64, 64))

col1, col2 = st.columns(2)
with col1:
    if st.button("Iterate ψ-Field 🔄"):
        f = st.session_state.psi_field
        lap = (np.roll(f,1,0)+np.roll(f,-1,0)+np.roll(f,1,1)+np.roll(f,-1,1)-4*f)
        st.session_state.psi_field += 0.5*lap + np.random.normal(0,0.01,f.shape)
        st.toast("ψ-Field evolved ✨")

with col2:
    if st.button("Surprise Me 🎁"):
        x, y = random.randint(0,63), random.randint(0,63)
        st.session_state.psi_field[x,y] += random.uniform(-1,1)
        st.balloons()

st.image(st.session_state.psi_field, caption="ψ-Field State", clamp=True)
st.caption("Run via Streamlit Cloud or locally with: streamlit run z88_streamlit_app_interactive_plus.py")

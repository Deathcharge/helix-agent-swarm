# 🌀 Z-88 Ritual Engine – Interactive Plus
A deployable Streamlit app simulating a recursive ψ-field.

## Deploy on Streamlit Cloud
1. Push this folder to GitHub
2. Go to [https://streamlit.io/cloud](https://streamlit.io/cloud)
3. Choose repository and select `z88_streamlit_app_interactive_plus.py` as main file
4. Click Deploy 🚀

## Local Run
```bash
pip install -r requirements.txt
streamlit run z88_streamlit_app_interactive_plus.py
```

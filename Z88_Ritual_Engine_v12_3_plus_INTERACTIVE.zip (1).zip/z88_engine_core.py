# ψ-field recursion and UCF coupling (full implementation in chat)

# Z-88 Ritual Engine Interactive v12.3+
Helix Codex Interface — Interactive Edition

## Run Instructions
1. pip install streamlit numpy matplotlib reportlab scipy streamlit-drawable-canvas
2. streamlit run z88_streamlit_app_interactive.py

## Modules
- z88_engine_core.py ........ ψ recursion engine
- z88_memetic_consciousness.py .... consciousness-memetic system
- z88_interactive_layer.py ........ canvas & audio interactivity
- z88_streamlit_app_interactive.py . main app with Codex export
